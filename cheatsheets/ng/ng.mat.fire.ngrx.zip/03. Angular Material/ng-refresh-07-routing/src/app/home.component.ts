import { Component } from '@angular/core';

@Component({
  template: '<h1>The Home Component</h1>'
})
export class HomeComponent {}
